package RecipeAI;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
/* Course: CS4242
Tony Seo
Student ID: 000-77-2225
Assignment #2
Due Date: 10/21/2018
  */

public class RecipeFinder {
    public static void main(String[] args) throws Exception {
        //Creates three array lists one for the item name,one for the ingredients,and one for user inputted ingredients
        ArrayList<String> recipes = new ArrayList<String>();
        ArrayList<String> ingredients = new ArrayList<String>();
        ArrayList<String> List = new ArrayList<String>();

        // pass the path to the file as a parameter
        File file1 =
                new File("D:\\User\\RecipeFinderAI\\src\\RecipeAI\\TestRecipes.txt");
        Scanner sc1 = new Scanner(file1);

        File file2 =
                new File("D:\\User\\RecipeFinderAI\\src\\RecipeAI\\Ingredients.txt");
        Scanner sc2 =  new Scanner(file2);
        //Scans until the text document is done

        //Adds potential recipe items
        while (sc1.hasNextLine()) {
            recipes.add(sc1.nextLine());
        }

        //Adds ingredients of those recipe items
        while (sc2.hasNextLine()) {
            ingredients.add(sc2.nextLine());
        }

        //Scanner for
        Scanner sc3 = new Scanner(System.in);
        String ingredientList;
        //Requests User Input for the Ingredients that they have in their house
        System.out.println("Welcome to recipe matcher");
        System.out.println("\n" + "The goal of this application is to match the the current ingredients in your pantry with potential food items that you can make");
        System.out.println("\n" + "Please enter the ingredients you have in your pantry currently separated by commas and no spaces");
        ingredientList = sc3.nextLine();
        //Temporary int variable to start at beginning of the list of ingredients inputted
        int tempInt = 0;
        //Stores ingredients inputted into an ArrayList
        for(int i = 0;i<ingredientList.length();i++){
            //Condition to add Last item
            if(i == ingredientList.length()-1){
                List.add(ingredientList.substring(tempInt,i+1));
            }
            //Adds items to list separated by commas
            if(ingredientList.charAt(i) == ','){
                List.add(ingredientList.substring(tempInt,i));
                tempInt = i + 1;
            }
        }
        //temporary string to store pantry
        String tempString;
        Boolean finished = false;
        //Matches Ingredients with recipes
        //For loop checks items from the first list to see if they have any ingredients that matches with any recipe ingredients
        //Checks for solutions by deleting ingredient names  and if there is no more ingredient names left on the recipe ingredients then you found a match
        for(int i = 0;i<List.size();i++){
            //Creates a temporary int variable to act as first number
            //Goes through the recipe ingredients list
            for(int j = 0;j<ingredients.size();j++){
                //Checks each line in the recipe Ingredients list separated by commas
                for(int k = 0;k<ingredients.get(j).length();k++){
                    //Case for last ingredient
                    if(k+1 == ingredients.get(j).length()){
                        if(List.get(i).equals(ingredients.get(j).substring(0,k+1))){
                            ingredients.set(j,"");
                            finished = true;
                        }
                    }
                    //If the ingredient name matches with the ingredient you have in your pantry
                    if(!finished) {
                        if (ingredients.get(j).charAt(k) == ',') {
                            if (List.get(i).equals(ingredients.get(j).substring(0, k))) {
                                tempString = ingredients.get(j).substring(k + 1, ingredients.get(j).length());
                                ingredients.set(j, tempString);
                                k = -1;
                            }
                        }
                    }
                }
            }
            finished = false;
        }
        //Flag to see is there are no matches
        boolean noMatches = true;
        //Checks to see if there was a match
        for(int i = 0;i<ingredients.size();i++){
            if(ingredients.get(i).equals("")){
                noMatches = false;
                System.out.println("You can make " + recipes.get(i));
            }
        }
        //Prints out if there wasn't a match
        if(noMatches){
            System.out.println("There were no matches found in our database");
        }

        /*Testers to see if they were properly added to the arraylists
        for(int i = 0;i<recipes.size();i++){
            System.out.println(recipes.get(i));
        }

        for(int i = 0;i<ingredients.size();i++){
            System.out.println(ingredients.get(i));
        }

        for(int i = 0;i<List.size();i++){
            System.out.println(List.get(i));
        }


        */
        }
    }
